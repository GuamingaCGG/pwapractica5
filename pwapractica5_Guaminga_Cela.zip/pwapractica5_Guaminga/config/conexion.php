<?php
$host = "sql303.infinityfree.com";
$user = "if0_41883543";
$pass = "gcchristR17";
$db   = "if0_41883543_gestiondetareas";

$conexion = mysqli_connect($host, $user, $pass, $db);

if (!$conexion) {
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body>";
    echo "<h2>Error de conexion: " . mysqli_connect_error() . "</h2>";
    echo "</body></html>";
    exit();
}

mysqli_set_charset($conexion, "utf8");
?>
